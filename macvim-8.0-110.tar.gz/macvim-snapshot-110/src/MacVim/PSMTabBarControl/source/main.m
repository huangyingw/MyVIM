//
//  main.m
//  TabBarControl
//
//  Created by John Pannell on 12/18/05.
//  Copyright Positive Spin Media 2005. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
